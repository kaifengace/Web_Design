#!/usr/bin/env python
# coding: utf-8

# In[ ]:
import csv

def search4phrase(phrase:str) -> set:
    csvfile = open('records_B.csv', 'r')
    reader = csv.DictReader(csvfile, )
    for row in reader:
        if row["firstname"]==phrase :
            return "班级是："+row["lastname"]+"github是:"+row["github"]+"  segmentfault是:"+row["segmentfault"]+"  email是:"+row['email'],(row["firstname"],row["username"])
    return "没有找到",(phrase,"")

def search4letters(letters) :
    csvfile = open('records_B.csv', 'r')
    reader = csv.DictReader(csvfile, )
    for row in reader:
        if row["username"] == letters:
            return "班级是：" + row["lastname"] + "github是:" + row["github"] + "  segmentfault是:" + row["segmentfault"] + "  email是:" + row['email'],(row["firstname"],row["username"])
    return "没有找到",("",letters)

def information(phrase:str,letters:str='') -> str:
    if phrase=="":
        return search4letters(letters)
    if letters=="":
        return search4phrase(phrase)
    csvfile = open('records_B.csv','r')
    reader = csv.DictReader(csvfile,)
    for row in reader:
        if row["firstname"]==phrase and row["username"]==letters:
            return "班级是："+row["lastname"]+"  github是:"+row["github"]+"  segmentfault是:"+row["segmentfault"]+"  email是:"+row['email'],(row["firstname"],row["username"])
    return "没有找到",("",letters)
