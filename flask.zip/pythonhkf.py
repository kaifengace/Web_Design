from flask import Flask, render_template, request
from vsearch import information
app=Flask(__name__)
@app.route('/vsearch',methods=['POST'])
def do_search() -> 'html':
      phrase=request.form['phrase']
      letters=request.form['letters']
      data = information(phrase, letters)
      title='这是你的结果:'
      results=str(data[0])
      phrase,letters=data[1]
      return render_template('results.html',
                                            the_title=title,
                                            the_phrase=phrase,
                                            the_letters=letters,
                                            the_results=results,)
@app.route('/')
@app.route('/entry')
def entry_page()->'html':
      return render_template('entry.html',
                             the_title='欢迎查询自己的信息')
if __name__ == '__main__':
    app.run(debug=True)
